package PGR208.exam.edamamapp

import PGR208.exam.edamamapp.models.Meal

object MealList {
    val mealsList = mutableListOf<Meal>()
}