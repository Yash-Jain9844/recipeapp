package PGR208.exam.edamamapp

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import PGR208.exam.edamamapp.databinding.RecipeItemBinding
import PGR208.exam.edamamapp.Database_Favorites.FavoritesDao
import PGR208.exam.edamamapp.Database_Favorites.FavoritesEntity
import PGR208.exam.edamamapp.Database_searchHistory.SearchHistoryEntity
import PGR208.exam.edamamapp.Database_settings.SettingsDao
import PGR208.exam.edamamapp.R
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch

class SearchHistoryAdapter(
    private val searchHistoryEntityList: MutableList<SearchHistoryEntity>,
    val context: Context,
    private val favoritesDao: FavoritesDao,
    private val settingsDao: SettingsDao
) : RecyclerView.Adapter<SearchHistoryAdapter.SearchHistoryViewHolder>() {

    inner class SearchHistoryViewHolder(private val itemBinding: RecipeItemBinding) : RecyclerView.ViewHolder(itemBinding.root) {
        val ibFavorite = itemBinding.ibFavorite
        val btnSelectRecipe = itemBinding.btnSelectRecipe

        fun bindItem(searchHistoryEntity: SearchHistoryEntity) {
            Glide.with(context).load(searchHistoryEntity.image).into(itemBinding.ivDish)
            itemBinding.tvTitle.text = searchHistoryEntity.label
            itemBinding.tvDietLabel1.text = searchHistoryEntity.dietLabel
            itemBinding.tvHealthLabel1.text = searchHistoryEntity.healthLabel
            itemBinding.tvMealLabel.text = searchHistoryEntity.mealType
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SearchHistoryViewHolder {
        return SearchHistoryViewHolder(RecipeItemBinding.inflate(LayoutInflater.from(parent.context), parent, false))
    }

    override fun onBindViewHolder(holder: SearchHistoryViewHolder, position: Int) {
        val searchHistoryEntity = searchHistoryEntityList[position]
        holder.bindItem(searchHistoryEntity)

        holder.ibFavorite.setOnClickListener {
            if (holder.ibFavorite.background.equals(R.color.main_screen_content_background)) {
                GlobalScope.launch {
                    favoritesDao.insert(FavoritesEntity(0, searchHistoryEntity.label))
                    holder.ibFavorite.setBackgroundColor(R.color.red)
                }
            } else if (holder.ibFavorite.background.equals(R.color.red)) {
                GlobalScope.launch {
                    favoritesDao.delete(FavoritesEntity(0, searchHistoryEntity.label))
                    holder.ibFavorite.setBackgroundColor(R.color.main_screen_content_background)
                }
            }
        }

        holder.btnSelectRecipe.setOnClickListener {
            val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse(searchHistoryEntity.url))
            context.startActivity(browserIntent)
        }
    }

    override fun getItemCount(): Int {
        return searchHistoryEntityList.size
    }
}