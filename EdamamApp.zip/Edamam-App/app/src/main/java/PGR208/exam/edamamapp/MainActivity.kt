package PGR208.exam.edamamapp

import PGR208.exam.edamamapp.Database_searchHistory.SearchHistoryEntity
import PGR208.exam.edamamapp.Database_settings.SettingsEntity
import PGR208.exam.edamamapp.databinding.ActivityMainBinding
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import PGR208.exam.edamamapp.models.MealResponse
import PGR208.exam.edamamapp.network.RecipeService
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import android.Manifest
import android.util.Log

class MainActivity : AppCompatActivity() {
    private var binding: ActivityMainBinding? = null
    private var searchInput: String = ""
    private var searchBtn: Button? = null
    private var settingsBtn: Button? = null
    private var searchHistoryBtn: Button? = null
    private var maxSearchHistoryItems: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        if (isPermissionGranted()) {
            setupUI()
        } else {
            requestInternetPermission()
        }

        val settingsDao = (application as DatabaseApp).dbSettings.settingsDao()

        lifecycleScope.launch {
            if (settingsDao.getRowCount() == 0) {
                settingsDao.insert(
                    SettingsEntity(
                        desiredDiet = "None",
                        mealPriority = "None",
                        maxSearchHistoryItems = 10
                    )
                )
            }
        }


    }

    override fun onDestroy() {
        super.onDestroy()
        binding = null
    }

    private fun setupUI() {
        val settingsDao = (application as DatabaseApp).dbSettings.settingsDao()
        val searchHistoryDao = (application as DatabaseApp).dbSearchHistory.searchHistoryDao()

        // Initialize settings (remove calorie-related logic)
        lifecycleScope.launch {
            settingsDao.fetchMaxSearchHistoryItems().collect { result ->
                maxSearchHistoryItems = result ?: 10  // ✅ Default to 10 if null
            }
        }



        searchBtn = binding?.btnSearch
        searchBtn?.setOnClickListener {
            if (isPermissionGranted()) {
                MealList.mealsList.clear()
                searchInput = binding?.tvSearchInput?.text.toString()
                searchMeals(searchInput)
            } else {
                Toast.makeText(this, "No internet permission", Toast.LENGTH_SHORT).show()
            }
        }

        settingsBtn = binding?.btnSettings
        settingsBtn?.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }

        searchHistoryBtn = binding?.btnSearchHistory
        searchHistoryBtn?.setOnClickListener {
            val intent = Intent(this, SearchHistoryActivity::class.java)
            startActivity(intent)
        }
    }

    private fun isPermissionGranted(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED
    }

    private fun requestInternetPermission() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.INTERNET), Constants.INTERNET_PERMISSION_REQUEST_CODE)
    }

    private fun searchMeals(query: String) {
        if (Constants.isNetworkAvailable(this)) {
            val retrofit: Retrofit = Retrofit.Builder()
                .baseUrl(Constants.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            val service: RecipeService = retrofit.create(RecipeService::class.java)
            val call: Call<MealResponse> = service.searchMeals(query)

            call.enqueue(object : Callback<MealResponse> {
                override fun onResponse(call: Call<MealResponse>, response: Response<MealResponse>) {
                    if (response.isSuccessful) {
                        val mealResponse: MealResponse? = response.body()
                        val searchHistoryDao = (application as DatabaseApp).dbSearchHistory.searchHistoryDao()

                        if (mealResponse?.meals != null) {
                            MealList.mealsList.addAll(mealResponse.meals)
                            if (MealList.mealsList.size >= maxSearchHistoryItems) {
                                SearchHistoryEntityList.searchHistoryEntityList.clear()
                                for (i in 0 until maxSearchHistoryItems) {
                                    lifecycleScope.launch {
                                        searchHistoryDao.deleteAll()

                                        val maxItems = minOf(maxSearchHistoryItems, MealList.mealsList.size)

                                        for (i in 0 until maxItems) {
                                            val meal = MealList.mealsList[i]
                                            searchHistoryDao.insert(
                                                SearchHistoryEntity(
                                                    image = meal.strMealThumb,
                                                    label = meal.strMeal,
                                                    dietLabel = meal.strCategory,
                                                    healthLabel = "",
                                                    mealType = meal.strCategory,
                                                    url = meal.strSource ?: ""
                                                )
                                            )
                                        }
                                    }

                                    SearchHistoryEntityList.searchHistoryEntityList.add(
                                        SearchHistoryEntity(
                                            id = i,
                                            image = MealList.mealsList[i].strMealThumb,
                                            label = MealList.mealsList[i].strMeal,
                                            dietLabel = MealList.mealsList[i].strCategory,
                                            healthLabel = "",
                                            mealType = MealList.mealsList[i].strCategory,
                                            url = MealList.mealsList[i].strSource ?: ""

                                        )
                                    )
                                }
                            }
                            val adapter = MainAdapter(
                                MealList.mealsList,
                                this@MainActivity,
                                favoritesDao = (application as DatabaseApp).dbFavorites.favoritesDao(),
                                settingsDao = (application as DatabaseApp).dbSettings.settingsDao()
                            )
                            binding?.rvRecipe?.adapter = adapter
                        }
                    } else {
                        Log.e("Error ${response.code()}", response.message())
                    }
                }

                override fun onFailure(call: Call<MealResponse>, t: Throwable) {
                    Log.e("Error", t.message.toString())
                    Toast.makeText(this@MainActivity, "Network error", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this@MainActivity, "No internet connection", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == Constants.INTERNET_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                setupUI()
            } else {
                Toast.makeText(this, "No internet permission", Toast.LENGTH_SHORT).show()
            }
        }
    }


}