package PGR208.exam.edamamapp

import PGR208.exam.edamamapp.DatabaseApp
import PGR208.exam.edamamapp.Database_searchHistory.SearchHistoryEntity
import PGR208.exam.edamamapp.SearchHistoryEntityList
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import PGR208.exam.edamamapp.databinding.ActivitySearchHistoryBinding
import PGR208.exam.edamamapp.SearchHistoryAdapter
import kotlinx.coroutines.launch

class SearchHistoryActivity : AppCompatActivity() {
    private var binding: ActivitySearchHistoryBinding? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySearchHistoryBinding.inflate(layoutInflater)
        setContentView(binding?.root)

        val favoritesDao = (application as DatabaseApp).dbFavorites.favoritesDao()
        val settingsDao = (application as DatabaseApp).dbSettings.settingsDao()
        val searchHistoryDao = (application as DatabaseApp).dbSearchHistory.searchHistoryDao()

        lifecycleScope.launch {
            searchHistoryDao.fetchAllSearchHistoryEntities().collect {
                SearchHistoryEntityList.searchHistoryEntityList = it as MutableList<SearchHistoryEntity>
                val adapter = SearchHistoryAdapter(
                    SearchHistoryEntityList.searchHistoryEntityList,
                    this@SearchHistoryActivity,
                    favoritesDao = favoritesDao,
                    settingsDao = settingsDao
                )
                binding?.rvRecipe?.adapter = adapter
            }
        }
    }
}